"use client";
import Image from "next/image";
import Nav from "./Nav";
import Hero from "./Hero";
import AccordionWall from "./AccordianWall";
import CurvedLoop from "@/components/CurvedLoop";


export default function Homepage() {
    return (
        <>
            <Nav />
            <Hero />


            <AccordionWall />
        </>
    );
}
